#!/bin/sh

# install zd-link1000 linux kernel driver

path=$1
ZDLINK_DRIVER_FILE="zdlink-compliant.ko"
KERNEL_DRIVER_MODULE="lan78xx.ko"
KERNEL_DRIVER_BACKUP="lan78xx.ubuntu"

KERNEL_DRIVE_PATH="/lib/modules/"$(uname -r)"/kernel/drivers/net/usb/"


echo
echo "******* Installation of zd-link1000 kernel driver by ZD-Automotive GmbH *******"
echo "Notice: Before installation, disconnect zd-link1000 usb cable"
echo "        It's ok if rmmod implies Module is not currently loaded"
echo

if [ $# -ne 1 ] ; then
        echo "usage: zdlink-install.sh <path to driver>"
        exit
fi

check_cmd()
{
        $1

        if [ $? -ne 0 ];then
            echo "FAILED!!!"
            echo
            exit 1
        fi
}

sudo check_cmd

sudo rmmod ${KERNEL_DRIVER_MODULE}

sudo mv -n ${KERNEL_DRIVE_PATH}${KERNEL_DRIVER_MODULE} ${KERNEL_DRIVE_PATH}${KERNEL_DRIVER_BACKUP}

sudo cp -f $path/${ZDLINK_DRIVER_FILE} ${KERNEL_DRIVE_PATH}${KERNEL_DRIVER_MODULE}

printf "OK: zd-link1000 driver is installed to ${KERNEL_DRIVE_PATH}\n"
printf "OK: ubuntu system driver is backuped as <${KERNEL_DRIVER_BACKUP}>\n"
echo


