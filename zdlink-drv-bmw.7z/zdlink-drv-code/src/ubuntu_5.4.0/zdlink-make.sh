#!/bin/sh

# make modules for zd-link1000 linux kernel driver

SAVE_MAKEFILE="Makefile-compliant"

KO_FILE="/lan78xx-compliant.ko"
ZD_KO_FILE="/zdlink-compliant.ko"



WORK_MAKEFILE="Makefile"
KERNEL_DRIVER_FILE="lan78xx-compliant.ko"

sudo cp -f ${SAVE_MAKEFILE} ${WORK_MAKEFILE}

sudo mkdir -p $1

sudo make clean

sudo make modules version=$1 drv_version=$2

sudo rm -rf *.o *~ core .depend .*.cmd *.mod *.mod.c *.order *.symvers .cache.mk *.ur-safe .tmp_versions Makefile

echo

printf "Successfully generate kernel driver file <${KERNEL_DRIVER_FILE}> \n" #before signature\n"

echo

# printf "++++++Begin sign file <${KO_FILE}> \n"
sudo cp -f ./$1${KO_FILE} ./$1${ZD_KO_FILE}
sudo rm -f ./$1${KO_FILE}
# rm -rf ${ZD_KO_FILE[i]}
# kmodsign sha512 ./../../cert/MOK.priv ./../../cert/MOK.der "./"$1${KO_FILE} $1${ZD_KO_FILE}

# printf "++++++End sign file <${KO_FILE}> \n"


echo

