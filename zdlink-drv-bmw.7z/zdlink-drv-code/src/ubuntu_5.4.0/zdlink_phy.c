/*
 * Copyright (C) 2020 ZD-Automotive GmbH
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 */

/* This file is include in lan78xx.c to support ZD-Link1000 USB 1000Base-T1 net stick */
/**************************** include files *************************************/
#include <linux/phy_led_triggers.h>

/**************************** MACROS and Constants ******************************/
#define ZD_MAC_OUI_BYTE0  0xFC
#define ZD_MAC_OUI_BYTE1  0x88
#define ZD_MAC_OUI_BYTE2  0x88

#define ZD_LINK_PHY_ID    0x1

#define PCS_CONTROL_DEVICE                 0x3
#define PCS_CONTROL_REG                    0x0
#define PCS_100BASET1_LINK_STATUS_REG      0x8109
#define PCS_1000BASET1_LINK_STATUS_REG     0x0901

#define PMD_PMA_CONTROL_DEVICE             0x1
#define PMD_1000BASET1_TRAINING_REG        0x0902
#define PMD_1000BASET1_PEER_TRAINING_REG   0x0903

/* 1000BASE-T1 Operating Mode */
#define MRVL_88Q2112_MODE_LEGACY           0x06B0                
#define MRVL_88Q2112_MODE_DEFAULT          0x0000
#define MRVL_88Q2112_MODE_MSK              0x07F0
#define MRVL_88Q2112_MODE_ADVERTISE        0x0002
#define MRVL_88Q2112_MODE_ERROR            0xFFFF

#define MRVL_88Q2112_MODE_REG1_ADDR        0xFDB8
#define MRVL_88Q2112_MODE_REG1_VAL         0x0001
#define MRVL_88Q2112_MODE_REG2_ADDR        0xFD3D
#define MRVL_88Q2112_MODE_REG2_VAL         0x0C14
/**************************** Function prototypes *******************************/

static int zd_phy_connect_direct(struct net_device *dev, struct phy_device *phydev,
		       void (*handler)(struct net_device *),
		       phy_interface_t interface);
static int zd_phy_attach_direct(struct net_device *dev, struct phy_device *phydev,
		      u32 flags, phy_interface_t interface);
static void genphy_zdlink_link_change(struct phy_device *phydev, bool up, bool do_carrier);

/* MDIO access */
static int genphy_zdlink_read_mdio(struct mii_bus *bus, int phy_id, int device, int reg);
static int genphy_zdlink_write_mdio(struct mii_bus *bus, int phy_id, int device, int reg, u16 regval);
static int zd_phy_init_hw(struct phy_device *phydev);

/* PHY device func */
static int zdlink_phy_init(void);
static void zdlink_phy_exit(void);

static int genphy_zdlink_soft_reset(struct phy_device *phydev);
static int genphy_zdlink_config_init(struct phy_device *phydev);
static int genphy_zdlink_config_aneg(struct phy_device *phydev);
static int genphy_zdlink_aneg_done(struct phy_device *phydev);
static int genphy_zdlink_read_status(struct phy_device *phydev);
static int genphy_zdlink_suspend(struct phy_device *phydev);
static int genphy_zdlink_resume(struct phy_device *phydev);
static int genphy_zdlink_loopback(struct phy_device *phydev, bool enable);

/* MAC device func */

static int zd_is_valid_zdlink_mac(struct lan78xx_net *dev);
static void zd_set_static_config(struct lan78xx_net *dev);
/**********************************************************************************/

////////////// ZD-LINK1000 PHY DRIVER ///////////////
/**
 * genphy_zdlink_soft_reset- software reset the PHY via BMCR_RESET bit
 * @phydev: target phy_device struct
 *
 * Description: Perform a software PHY reset using the standard
 * BMCR_RESET bit and poll for the reset bit to be cleared.
 *
 * Returns: 0 on success, < 0 on failure
 */
static int genphy_zdlink_soft_reset(struct phy_device *phydev)
{
	/* Do nothing for now */
	return 0;
}

/**
 * genphy_zdlink_config_init- initialize features supported
 * @phydev: target phy_device struct
 *
 *  Returns: 0 on success or <0 on error
 */
static int genphy_zdlink_config_init(struct phy_device *phydev)
{
/* modified by  ZD-Automotvie 2020-05-27 */
/* modify phydev features format according to kernel 5.3.0 */
#if 0  
    u32 features;

    features = (SUPPORTED_TP | SUPPORTED_MII | SUPPORTED_AUI | SUPPORTED_Pause | SUPPORTED_Asym_Pause);
    features |= (SUPPORTED_100baseT_Full | SUPPORTED_1000baseT_Full);

    phydev->supported |= features;
    phydev->advertising |= features;

    return 0;
#endif
/* end of modification by  ZD-Automotvie 2020-05-27 */

	__ETHTOOL_DECLARE_LINK_MODE_MASK(features) = { 0, };

	linkmode_set_bit_array(phy_basic_ports_array,
			       ARRAY_SIZE(phy_basic_ports_array),
			       features);
	linkmode_set_bit(ETHTOOL_LINK_MODE_Pause_BIT, features);
	linkmode_set_bit(ETHTOOL_LINK_MODE_Asym_Pause_BIT, features);

	linkmode_set_bit(ETHTOOL_LINK_MODE_Autoneg_BIT, features);

	linkmode_set_bit(ETHTOOL_LINK_MODE_100baseT_Full_BIT, features);
	linkmode_set_bit(ETHTOOL_LINK_MODE_1000baseT_Full_BIT, features);


	linkmode_and(phydev->supported, phydev->supported, features);
	linkmode_and(phydev->advertising, phydev->advertising, features);

	return 0;
}

/**
 * genphy_zdlink_config_aneg - start auto-negotiation for this PHY device
 * @phydev: the phy_device struct
 *
 * Description: Sanitizes the settings (if we're not autonegotiating
 *   them), and then calls the driver's config_aneg function.
 *   If the PHYCONTROL Layer is operating, we change the state to
 *   reflect the beginning of Auto-negotiation or forcing.
 *  Returns: 0 on success or <0 on error
 */
static int genphy_zdlink_config_aneg(struct phy_device *phydev)
{
	return 0;
}

/**
 * genphy_zdlink_aneg_done - return auto-negotiation status
 * @phydev: target phy_device struct
 *
 * Description: Return the auto-negotiation status from this @phydev
 * Returns > 0 on success or < 0 on error. 0 means that auto-negotiation
 * is still pending.
 */
static int genphy_zdlink_aneg_done(struct phy_device *phydev)
{
	return 1; /* auto-negotiation success */
}

/**
 * genphy_zdlink_read_status - check the link status and update current link state
 * @phydev: target phy_device struct
 *
 * Description: Check the link, then figure out the current state
 *   by comparing what we advertise with what the link partner
 *   advertises.  Start by checking the gigabit possibilities,
 *   then move on to 10/100.
 *  Returns: 0 on success or <0 on error
 */
static int genphy_zdlink_read_status(struct phy_device *phydev)
{
    int phy_id=0, device=0, reg=0, regval=0;
    u8 speed_sel=0;
    struct mii_bus *bus = phydev->mdio.bus;

    phy_id=ZD_LINK_PHY_ID;

    /* set duplex */
    phydev->duplex = DUPLEX_FULL;

    /* get phy speed from pcs register 3.0.6:13 */
    device = PCS_CONTROL_DEVICE;
    reg=PCS_CONTROL_REG;

    regval = genphy_zdlink_read_mdio(bus, phy_id, device, reg);

    speed_sel = ( ((regval>>6)&0x1)<<1 ) | ((regval>>13)&0x1);
 
    if( speed_sel==0x2 ) {
            phydev->speed = SPEED_1000;  /* set 1000M for net device */
    }
    else {
            phydev->speed = SPEED_100;  /* set 100M for net device */
    }

//    printk("ZD-LInk PHY:  reg=0x%04X, value=0x%04X, speed=%d\n", reg, regval, phydev->speed);

    /* 
        get link status from phy register:
          100Base-T1: 3.8109.2
         1000Base-T1: 3.0901.2
    */
    device = PCS_CONTROL_DEVICE;
    if(  phydev->speed == SPEED_1000 )
        reg=PCS_1000BASET1_LINK_STATUS_REG;
    else
        reg=PCS_100BASET1_LINK_STATUS_REG;

    regval = genphy_zdlink_read_mdio(bus, phy_id, device, reg);

    if( ((regval>>2)&0x01) ) {
        phydev->link = 1; //set phydev link
    }
    else {
        phydev->link = 0; //set phydev link
    }

//    printk("ZD-LInk PHY: reg=0x%04X, value=0x%4X, link=%d\n", reg, regval, phydev->link);

#if 0
    /* check the status of 1000Base-T1 link training reg */
    phy_id=ZD_LINK_PHY_ID;
    device = PMD_PMA_CONTROL_DEVICE;
    /* get 1000Base-T1 training register 1.0902.1:0 */
    reg = PMD_1000BASET1_TRAINING_REG;
    regval = genphy_zdlink_read_mdio(bus, phy_id, device, reg);

    printk("ZD-LInk PHY: link training setting reg%d.%x=0x%04X\n", device, reg, regval);
    
    /* get 1000Base-T1 link parternet training register 1.0903.1:0 */
    reg = PMD_1000BASET1_PEER_TRAINING_REG;
    regval = genphy_zdlink_read_mdio(bus, phy_id, device, reg);

    printk("ZD-LInk PHY: link parternet training reg%d.%x=0x%04X\n", device, reg, regval); 
#endif

    return 0;
}

/**
 * genphy_zdlink_suspend - power down PHY in MII_BMCR reg
 * @phydev: target phy_device struct
 *
 *  Returns: 0 on success or <0 on error
 */
static int genphy_zdlink_suspend(struct phy_device *phydev)
{
	return 0;
}

/**
 * genphy_zdlink_resume- power up PHY in MII_BMCR reg
 * @phydev: target phy_device struct
 *
 *  Returns: 0 on success or <0 on error
 */
static int genphy_zdlink_resume(struct phy_device *phydev)
{
	return 0;
}

/**
 * genphy_zdlink_loopback- set PHY loopback mode in MII_BMCR reg
 * @phydev: target phy_device struct
 *
 *  Returns: 0 on success or <0 on error
 */
static int genphy_zdlink_loopback(struct phy_device *phydev, bool enable)
{
	return 0;
}

struct phy_driver genphy_zdlink_driver = {
	.phy_id         = 0xffffffff,
	.phy_id_mask    = 0xffffffff,
	.name           = "Generic ZDLink1000 PHY",
	.soft_reset   	= genphy_zdlink_soft_reset,
	.config_init    = genphy_zdlink_config_init,
	.features       = PHY_GBIT_FEATURES,
	.config_aneg    = genphy_zdlink_config_aneg,
	.aneg_done	= genphy_zdlink_aneg_done,
	.read_status    = genphy_zdlink_read_status,
	.suspend        = genphy_zdlink_suspend,
	.resume         = genphy_zdlink_resume,
	.set_loopback   = genphy_zdlink_loopback,
/* added by  ZD-Automotive 2020-06-04 */
        .mdiodrv.driver.owner = (struct module *)0xffffffff,
/* end of modification by  ZD-Automotive 2020-06-04 */
};


static void genphy_zdlink_link_change(struct phy_device *phydev, bool up, bool do_carrier)
{
    struct net_device *netdev = phydev->attached_dev;

    if (do_carrier) {
        if (up)
	    netif_carrier_on(netdev);
        else
	    netif_carrier_off(netdev);
    }
/* no need for zd-link phy */
//	phydev->adjust_link(netdev);
}

static int zdlink_phy_init(void)
{
    int ret=-1;
    ret = phy_driver_register(&genphy_zdlink_driver, THIS_MODULE);
    return ret;
}

static void zdlink_phy_exit(void)
{
    phy_driver_unregister(&genphy_zdlink_driver);
}

/**
 * phy_connect_direct - connect an ethernet device to a specific phy_device
 * @dev: the network device to connect
 * @phydev: the pointer to the phy device
 * @handler: callback function for state change notifications
 * @interface: PHY device's interface
 */
static int zd_phy_connect_direct(struct net_device *dev, struct phy_device *phydev,
		       void (*handler)(struct net_device *),
		       phy_interface_t interface)
{
	int rc;

	rc = zd_phy_attach_direct(dev, phydev, phydev->dev_flags, interface);
	if (rc)
		return rc;


//	phy_prepare_link(phydev, handler);
//The same as:
	phydev->adjust_link = handler;

	phy_start_machine(phydev);

	return 0;
}

/**
 * phy_attach_direct - attach a network device to a given PHY device pointer
 * @dev: network device to attach
 * @phydev: Pointer to phy_device to attach
 * @flags: PHY device's dev_flags
 * @interface: PHY device's interface
 *
 * Description: Called by drivers to attach to a particular PHY
 *     device. The phy_device is found, and properly hooked up
 *     to the phy_driver.  If no driver is attached, then a
 *     generic driver is used.  The phy_device is given a ptr to
 *     the attaching device, and given a callback for link status
 *     change.  The phy_device is returned to the attaching driver.
 *     This function takes a reference on the phy device.
 */
static int zd_phy_attach_direct(struct net_device *dev, struct phy_device *phydev,
		      u32 flags, phy_interface_t interface)
{
	struct module *ndev_owner = dev->dev.parent->driver->owner;
	struct mii_bus *bus = phydev->mdio.bus;
	struct device *d = &phydev->mdio.dev;
	bool using_genphy = false;
	int err;


	/* For Ethernet device drivers that register their own MDIO bus, we
	 * will have bus->owner match ndev_mod, so we do not want to increment
	 * our own module->refcnt here, otherwise we would not be able to
	 * unload later on.
	 */
	if (ndev_owner != bus->owner && !try_module_get(bus->owner)) {
		dev_err(&dev->dev, "failed to get the bus module\n");
		return -EIO;
	}

	get_device(d);

	/* Assume that if there is no driver, that it doesn't
	 * exist, and we should use the genphy driver.
	 */
	if (!d->driver) {
		d->driver = &genphy_zdlink_driver.mdiodrv.driver;

		using_genphy = true;
	}

	if (!try_module_get(d->driver->owner)) {
		dev_err(&dev->dev, "failed to get the device driver module\n");
		err = -EIO;
		goto error_put_device;
	}

	if (using_genphy) {
		err = d->driver->probe(d);
		if (err >= 0)
			err = device_bind_driver(d);

		if (err)
			goto error_module_put;
	}

	if (phydev->attached_dev) {
		dev_err(&dev->dev, "PHY already attached\n");
		err = -EBUSY;
		goto error;
	}

	phydev->phy_link_change = genphy_zdlink_link_change;
	phydev->attached_dev = dev;
	dev->phydev = phydev;

	/* Some Ethernet drivers try to connect to a PHY device before
	 * calling register_netdevice() -> netdev_register_kobject() and
	 * does the dev->dev.kobj initialization. Here we only check for
	 * success which indicates that the network device kobject is
	 * ready. Once we do that we still need to keep track of whether
	 * links were successfully set up or not for phy_detach() to
	 * remove them accordingly.
	 */
	phydev->sysfs_links = false;

	err = sysfs_create_link(&phydev->mdio.dev.kobj, &dev->dev.kobj,
				"attached_dev");
	if (!err) {
		err = sysfs_create_link(&dev->dev.kobj, &phydev->mdio.dev.kobj,
					"phydev");
		if (err)
			goto error;

		phydev->sysfs_links = true;
	}

	phydev->dev_flags = flags;

	phydev->interface = interface;

	phydev->state = PHY_READY;

	/* Initial carrier state is off as the phy is about to be
	 * (re)initialized.
	 */
	netif_carrier_off(phydev->attached_dev);


	/* Do initial configuration here, now that
	 * we have certain key parameters
	 * (dev_flags and interface)
	 */
	err = zd_phy_init_hw(phydev);
	if (err)
		goto error;

	phy_resume(phydev);

        /* phy_led_triggers will be called by PHY state machine in phy_device.c.
           if CONFIG_LED_TRIGGERS is not defined in kernel, the function has no effect.
         */
        phydev->speed = 0;  /* set spped 0 to skip speed change for led trigger */
	phy_led_triggers_register(phydev);

	return err;

error:
	/* phy_detach() does all of the cleanup below */
	phy_detach(phydev);
	return err;

error_module_put:
	module_put(d->driver->owner);
error_put_device:
	put_device(d);
	if (ndev_owner != bus->owner)
		module_put(bus->owner);
	return err;
}


/*
 *  ZD-Link1000 PHY mdio clause45 access
 */
#define PHY_XMDIO_CONTROL_REG     0x0D
#define PHY_XMDIO_DATA_REG        0x0E
#define PHY_XMDIO_DATA_WR_INC     0xC000
#define PHY_XMDIO_DATA_RDWR_INC   0x8000
#define PHY_XMDIO_DATA_NOINC      0x4000

/* mdio read */
static int genphy_zdlink_read_mdio(struct mii_bus *bus, int phy_id, int device, int reg)
{
    int regval=0;
    int ret=0;

    //write control_reg 0xd with device id
    ret = mdiobus_write(bus, phy_id, PHY_XMDIO_CONTROL_REG, (u16)device);
    //write data_reg 0xe with reg addr
    ret = mdiobus_write(bus, phy_id, PHY_XMDIO_DATA_REG, (u16)reg);
    //write control_reg 0xd with data operation
    ret = mdiobus_write(bus, phy_id, PHY_XMDIO_CONTROL_REG, (u16)(PHY_XMDIO_DATA_NOINC|device)); 
    //read data_reg to get value    
    regval = mdiobus_read(bus, phy_id, PHY_XMDIO_DATA_REG);

    return regval;
}

/* mdio write */
static int genphy_zdlink_write_mdio(struct mii_bus *bus, int phy_id, int device, int reg, u16 regval)
{
    int ret=0;

    //write control_reg 0xd with device id
    ret = mdiobus_write(bus, phy_id, PHY_XMDIO_CONTROL_REG, (u16)device);
    //write data_reg 0xe with reg addr
    ret = mdiobus_write(bus, phy_id, PHY_XMDIO_DATA_REG, (u16)reg);
    //write control_reg 0xd with data operation
    ret = mdiobus_write(bus, phy_id, PHY_XMDIO_CONTROL_REG, (u16)(PHY_XMDIO_DATA_NOINC|device)); 
    //write data_reg with value    
    ret = mdiobus_write(bus, phy_id, PHY_XMDIO_DATA_REG, regval);

    return ret;
}

/*
    Initialize zd-link1000 phy parameters via XMDIO interface
*/
static int zd_phy_init_hw(struct phy_device *phydev)
{
	struct mii_bus *bus = phydev->mdio.bus;
    int phy_id=0, device=0, reg=0, regval=0;
    int ret=0;
   

    /* currently no need init phy setting */
    return ret;

    printk("MDIO bus name: %s\n", bus->name);
    printk("MDIO bus read: %p\n", bus->read);
    printk("MDIO bus write: %p\n", bus->write);

    phy_id=1;
    // read zd-link1000 phy device 3 reg 0x8000
    device=3; 
    reg=0x8000;
    regval = genphy_zdlink_read_mdio(bus, phy_id, device, reg);
    printk("ZD-Link1000 PHY %d: %d.0x%04x = 0x%04x\n", phy_id, device, reg, regval);

    // read zd-link1000 phy device 31 reg 0x8001
    device=31; 
    reg=0x8001;
    regval = genphy_zdlink_read_mdio(bus, phy_id, device, reg);
    printk("ZD-Link1000 PHY %d: %d.0x%04x = 0x%04x\n", phy_id, device, reg, regval);


   

    // reset rgmii by set phy device 3 reg 0x8000
    device=3; 
    reg=0x8000;
    regval = 0x8000;
    ret = genphy_zdlink_write_mdio(bus, phy_id, device, reg, regval);   


    // set zd-link1000 phy device 31 reg 0x8001 rgmii mode2
    device=31; 
    reg=0x8001;
    regval = 0xc000;
    ret = genphy_zdlink_write_mdio(bus, phy_id, device, reg, regval);

    device=3; 
    reg=0x8000;
    regval = 0x0000;
    ret = genphy_zdlink_write_mdio(bus, phy_id, device, reg, regval);   


    // read zd-link1000 phy device 31 reg 0x8001
    device=31; 
    reg=0x8001;
    regval = genphy_zdlink_read_mdio(bus, phy_id, device, reg);
    printk("ZD-Link1000 PHY %d: %d.0x%04x = 0x%04x\n", phy_id, device, reg, regval);

    // read zd-link1000 phy device 4 reg 0x8000
    device=4; 
    reg=0x8000;
    regval = genphy_zdlink_read_mdio(bus, phy_id, device, reg);
    printk("ZD-Link1000 PHY %d: %d.0x%04x = 0x%04x\n", phy_id, device, reg, regval);
    
    return ret;
}

/*
 * zd_is_valid_zdlink_mac(struct lan78xx_net *dev):
 * Function: check if valid zd-link prodect by judge mac address
 *           zd-automotvie common mac oui: FC-88-88-xx-xx-xx
 * Output: 0:success; -1:fail
 */
static int zd_is_valid_zdlink_mac(struct lan78xx_net *dev)
{
    u32 addr_lo, addr_hi;
    int ret;
    u8 addr[6];

    ret = lan78xx_read_reg(dev, RX_ADDRL, &addr_lo);
    ret = lan78xx_read_reg(dev, RX_ADDRH, &addr_hi);

    addr[0] = addr_lo & 0xFF;
    addr[1] = (addr_lo >> 8) & 0xFF;
    addr[2] = (addr_lo >> 16) & 0xFF;
    addr[3] = (addr_lo >> 24) & 0xFF;
    addr[4] = addr_hi & 0xFF;
    addr[5] = (addr_hi >> 8) & 0xFF;
  
    printk("ZD-Link MAC address: %02x:%02x:%02x:%02x:%02x:%02x\n",
        addr[0],addr[1],addr[2],addr[3],addr[4],addr[5]);

    ret = -1;
//    if( (addr[0]==ZD_MAC_OUI_BYTE0)&&(addr[1]==ZD_MAC_OUI_BYTE1)&&(addr[2]==ZD_MAC_OUI_BYTE2) )
    if( (addr[1]==ZD_MAC_OUI_BYTE1)&&(addr[2]==ZD_MAC_OUI_BYTE2) )
    {
        ret = 0;
    }
      
    return ret;
}

/*
 * static void zd_set_static_config(struct lan78xx_net *dev);(struct lan78xx_net *dev):
 * Function: set mac&phy mode
 *           speed 100/1000
 *           full-duplex
 *           auto negociation
 *           link up
 * Output: 0:success; -1:fail
 */
static void zd_set_static_config(struct lan78xx_net *dev)
{
    struct phy_device *phydev = dev->net->phydev;

#ifdef ZDLINK_MODE_LEGACY
        /* support from ZD-Automotive */
        printk("ZD-Link is in Legacy mode (deprecated)\r\n");
#else
        printk("ZD-Link is in Compliant mode\r\n");
#endif

    phydev->speed = 0;  //speed will be changed in phy_read_status

    /* set auto-negociation */
    phydev->autoneg = AUTONEG_ENABLE;

    /* set duplex */
    phydev->duplex = DUPLEX_FULL;

    /* set link off in init state */
    phydev->link = 0;              //set phydev link
/* modified by  ZD-Automotvie 2020-05-27 */
/* modify phydev features format according to kernel 5.3.0 */
//    phydev->link_timeout = 0;
/* end of modification by  ZD-Automotvie 2020-05-27 */
    dev->link_on = 0;              //set dev link
}

/* end of ZD-Link1000 Phy driver */

